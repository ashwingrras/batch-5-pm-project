package org.example.generics;


public interface GenericInterfaceExample2<A>
{
    A multiply(A a, A b);
}
