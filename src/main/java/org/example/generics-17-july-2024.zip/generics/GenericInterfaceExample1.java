package org.example.generics;

public interface GenericInterfaceExample1<T>
{

    T sum(T a, T b);

}
